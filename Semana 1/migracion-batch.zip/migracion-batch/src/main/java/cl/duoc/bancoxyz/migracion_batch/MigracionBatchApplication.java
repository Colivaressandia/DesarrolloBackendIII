package cl.duoc.bancoxyz.migracion_batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MigracionBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(MigracionBatchApplication.class, args);
	}

}
